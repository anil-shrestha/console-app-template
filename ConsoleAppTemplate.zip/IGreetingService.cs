﻿namespace $safeprojectname$
{
    public interface IGreetingService
    {
        void Greet(string name);
    }
}